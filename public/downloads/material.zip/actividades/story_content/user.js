function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6hIAqac67xU":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

